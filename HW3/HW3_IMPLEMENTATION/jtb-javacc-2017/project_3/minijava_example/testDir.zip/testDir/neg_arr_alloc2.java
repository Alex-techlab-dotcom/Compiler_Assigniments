class neg_arr_alloc2 {
  public static void main(String[] a) {
    int[] b;
    int x;
    x = 1 - 2;
    b = new int[x];
  }
}
