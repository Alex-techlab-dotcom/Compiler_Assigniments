class Arrays {
	public static void main(String[] a) {
	    int[] x;
	    x = new int[2];

        x[0] = 1;
        x[1] = 2;

	    System.out.println((x[0]) + (x[1]));
	}
}
