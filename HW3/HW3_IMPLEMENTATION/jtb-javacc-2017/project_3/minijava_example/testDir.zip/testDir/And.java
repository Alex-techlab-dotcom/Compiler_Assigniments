class And {
	public static void main(String[] a) {
	    boolean b;
	    boolean c;
	    int x;
	    
        b = false;
        c = true;

        if (b && c)
            x = 0;
        else
            x = 1;

	    System.out.println(x);
	}
}
